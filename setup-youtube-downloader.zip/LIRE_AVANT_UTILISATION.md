# YouTube Downloader - Guide d'Installation

## ⚠️ Note Importante concernant les Antivirus

Lors du téléchargement ou de l'exécution de Family YouTube Downloader, Windows Defender ou votre antivirus pourrait afficher un avertissement. **Ne vous inquiétez pas, ceci est normal et votre application est sûre.**

### Pourquoi cela se produit-il ?

- L'application n'est pas signée avec un certificat numérique commercial
- Les logiciels de téléchargement YouTube sont souvent marqués comme suspects par les antivirus
- L'outil utilisé pour créer l'exécutable (PyInstaller) est parfois considéré comme suspect par Windows Defender

### Comment résoudre ce problème ?

### Option 1 : Ajouter une exception dans Windows Defender

1. Ouvrez les "Paramètres Windows Defender"
2. Allez dans "Protection contre les virus et les menaces"
3. Cliquez sur "Gérer les paramètres"
4. Faites défiler jusqu'à "Exclusions"
5. Cliquez sur "Ajouter ou supprimer des exclusions"
6. Ajoutez le dossier contenant Family YouTube Downloader

### Option 2 : Lors du téléchargement

1. Si votre navigateur bloque le téléchargement, cliquez sur "..." ou "Plus"
2. Sélectionnez "Conserver" ou "Conserver quand même"

### Option 3 : Lors de l'exécution

1. Si Windows bloque l'exécution, cliquez sur "Plus d'informations"
2. Puis cliquez sur "Exécuter quand même"

## Comment utiliser l'application

1. Décompressez le fichier ZIP dans un dossier de votre choix
2. Double-cliquez sur "Family YouTube Downloader.exe"
3. Collez l'URL de la vidéo YouTube que vous souhaitez télécharger
4. Cliquez sur "Télécharger"
5. Vos vidéos seront sauvegardées dans le dossier "videos"

## Support

Si vous rencontrez des problèmes :

- Assurez-vous d'avoir une connexion Internet stable
- Vérifiez que l'URL YouTube est valide
- Assurez-vous d'avoir assez d'espace disque

## Sécurité

Cette application est :

- ✅ 100% sûre et sans virus4
- ✅ Créée pour un usage familial
- ✅ Ne collecte aucune donnée personnelle
- ✅ Fonctionne localement sur votre ordinateur

Pour toute question supplémentaire, n'hésitez pas à contacter le développeur.
